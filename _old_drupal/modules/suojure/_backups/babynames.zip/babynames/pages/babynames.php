<?php

function babynames_pages_babynames () {
	global $user;
	if (!$user->uid) {
		drupal_set_message('Must login.', 'error');
		return '';
	}
	$content = '';
	
	drupal_add_css(drupal_get_path('module', 'babynames').'/css/babynames.css');
	
	// process posts
	babynames_add_name();
	babynames_rate_name();
	
	// get inputs and page state
	$vars = array();
	if (isset($_SESSION['babynames'])) $vars = $_SESSION['babynames'];
	if (isset($_GET['gender']) && is_numeric($_GET['gender'])) $vars['gender'] = (int)($_GET['gender']);
	if (isset($_GET['type']) && is_numeric($_GET['type'])) $vars['type'] = (int)($_GET['type']);
	elseif (!isset($vars['type'])) $vars['type'] = 0;
	
	if (isset($_GET['first']) && !empty($_GET['first'])) $vars['first'] = ($_GET['first']);
	elseif (!isset($vars['first'])) $vars['first'] = '';
	if (isset($_GET['middle']) && !empty($_GET['middle'])) $vars['middle'] = ($_GET['middle']);
	elseif (!isset($vars['middle'])) $vars['middle'] = '';
	
	$_SESSION['babynames'] = $vars;
	
	// first select gender
	$genders = array (0=>'Boy', 1=>'Girl');
	if (!isset($vars['gender']) || $vars['gender']<0) {
		$content .= '<ul class="gender-selector">';
		foreach ($genders as $g => $gender) 
			$content .= '<li>'.l($gender, 'babynames', array('query'=>array('gender'=>$g))).'</li>';
		$content .= '</ul>';
		unset($_SESSION['babynames']);
		return $content;
	}
	
	// get prime names for this gender
	db_set_active('babynames');
	$q = db_select('names', 'n');
	db_set_active();
	$q -> fields ('n', array ('name'))
	   -> condition ('n.gender', $vars['gender'])
	   -> condition ('n.root_variant', '')
	   -> orderBy ('n.name', 'ASC');
	$prime_names = $q->execute()->fetchAllAssoc('name');
 	
	// add new name form
	$origins = array ('?', 'celtic', 'english', 'german', 'greek', 'hebrew', 'irish', 'roman', 'slavic', 'spanish');
	$content .= babynames_pages_addnamesform ($vars['gender'], $prime_names, $origins);	
	
	// state selected gender
	$content .= 'Gender: '.$genders[$vars['gender']].' ('.l('reset', 'babynames', array('query'=>array('gender'=>-1))).')';	
	
	// select which name to work with
	$types = array (1=>'first', 2=>'middle');
	$content .= '<ul class="type-selector">';
	$initials = '';
	foreach ($types as $t => $type) {
		if (empty($vars[$type])) $text = '('.ucfirst($type).')';
		else {
			$text = ucfirst($vars[$type]);
			$initials .= $text[0].'.';
		}
		$content .= '<li class="clickable type-'.$type.' '.($t==$vars['type']?'selected':'').'">'.l($text, 'babynames', array('query'=>array('type'=>$t))).'</li>';
	}
	$content .= '<li>Anderson</li>';
	$content .= '<li class="initials">('.$initials.'A.)</li>';
	$content .= '</ul>';
	if ($vars['type'] < 1) return $content;
	
	// get all names
	db_set_active('babynames');
	$q = db_select('names', 'n');
	db_set_active();
	$q -> fields ('n', array ('name', 'root_variant'))
	   -> condition ('n.gender', $vars['gender'])
	   -> orderBy ('n.name', 'ASC');
	$all_names = $q->execute()->fetchAllAssoc('name');	
	
	db_set_active('babynames');
	$q = db_select('name_ratings', 'nr');
	db_set_active();
	$q -> fields ('nr', array ('name', 'fn_rating', 'mn_rating'))	
	   -> condition ('nr.user', $user->name);
	if ($vars['type'] > 0) $q -> orderBy ('nr.'.$types[$vars['type']][0].'n_rating', 'DESC');
	$name_ratings = $q->execute()->fetchAllAssoc('name');
	
	$content .= '<table class="baby-names baby-names-rated">';
	$content .= '<tr><th>First</th><th>Middle</th><th>Name</th><th>Root variant</th></tr>';
	foreach ($name_ratings as $name => $rating_data) {
		if (!isset($all_names[$name])) continue;
		$name_data = $all_names[$name];
		$content .= babynames_pages_namerow($vars['gender'], $types[$vars['type']], $name, $name_data, $rating_data);		
	}
	$content .= '</table>';

	$content .= '<table class="baby-names baby-names-unrated">';
	$content .= '<tr><th>First</th><th>Middle</th><th>Name</th><th>Root variant</th></tr>';	
	foreach ($all_names as $name => $name_data) {
		if (isset($name_ratings[$name])) continue;
		$content .= babynames_pages_namerow($vars['gender'], $types[$vars['type']], $name, $name_data);
	}
	$content .= '</table>';
	
	return $content;
}


function babynames_pages_namerow($gender, $type, $name, $name_data, $rating_data = null) {
	if (!isset($rating_data)) {
		$rating_data = new stdClass();
		$rating_data->fn_rating = 0;
		$rating_data->mn_rating = 0;
	}
	
	$content  = '<tr>';
	$content .= '<td><form method=POST>'.$rating_data->fn_rating;
		$content .= '<input type="hidden" name="ratename" value="'.$name.'" />';
		$content .= '<input type="hidden" name="ratename_gender" value="'.$gender.'" />';
		$content .= '<input type="submit" name="ratename_fup" value="+" />';
		$content .= '<input type="submit" name="ratename_fdown" value="-"/>';
		$content .= '</form></td>';
	$content .= '<td><form method=POST>'.$rating_data->mn_rating;
		$content .= '<input type="hidden" name="ratename" value="'.$name.'" />';
		$content .= '<input type="hidden" name="ratename_gender" value="'.$gender.'" />';
		$content .= '<input type="submit" name="ratename_mup" value="+" />';
		$content .= '<input type="submit" name="ratename_mdown" value="-"/>';
		$content .= '</form></td>';
	$content .= '<td class="col-name">';
		$content .= l(ucfirst($name), 'babynames', array('query'=>array($type=>$name)));
		$content .= '</td>';
	$content .= '<td class="col-root">'.(empty($name_data->root_variant)?'':'('.ucfirst($name_data->root_variant).')').'</td>';
	$content .= '</tr>';	
	return $content;
}


function babynames_pages_addnamesform ($gender, $prime_names, $origins) {
	$content = '<form method=POST style="float:right; margin-top: -7em;">
			<input type=hidden name=newname_gender value='.$gender.'></input>';
	$content .= '<table>';
		$content .= '<tr><td>Add name: </td><td><input name=newname></input></td></tr>';
		$content .= '<tr><td>Variant of: </td><td><select name="newname_root"><option value=0>-</option>';
			foreach ($prime_names as $name => $data) $content .= '<option value="'.$name.'">'.ucfirst($name).'</option>';
			$content .= '</select></td></tr>';
		$content .= '<tr><td>Origin:   </td><td><select name="newname_origin">';
			foreach ($origins as $o) $content .= '<option value="'.$o.'">'.ucfirst($o).'</option>';
			$content .= '</select></td></tr>';
		$content .= '<tr><td>Meaning:  </td><td><input name="newname_meaning"></input></td></tr>';
		$content .= '<tr><td></td><td><input type=submit value="Add name"></input></td></tr>';
	$content .= '</table></form>';	
	return $content;
}


function babynames_add_name () {
	if (!isset($_POST['newname']) || !isset($_POST['newname_gender'])) return;
	$_POST['newname'] = trim($_POST['newname']);
	$name = strtolower(sanitize($_POST['newname']));
	$gender = (int)$_POST['newname_gender'];
	if (!isset($_POST['newname_root']) || empty($_POST['newname_root']) || $_POST['newname_root'] === 0) $root = '';
	else $root = strtolower(sanitize($_POST['newname_root']));		
	
	db_set_active('babynames');
	$q = db_select('names', 'n');
	db_set_active();	
	$q -> fields ('n', array ('name'))
	   -> condition ('n.gender', $gender)
	   -> condition ('n.name', $name)
	   -> range (0,1);
	$count = $q -> countQuery() -> execute() -> fetchAssoc()['expression'];
	if ($count > 0) {
		drupal_set_message('Name "'.ucfirst($name).'" already exists.', 'warning');
		return;
	}
	
	db_set_active('babynames');
	$q = db_insert('names');
	db_set_active();
	$q -> fields (array('name' => $name, 'gender' => $gender, 'root_variant' => $root))
	   -> execute();
	   
	if (!empty($root)) return;
	
	if (!isset($_POST['newname_origin'])) $origin = '?';
	else $origin = strtolower(sanitize($_POST['newname_origin']));
	if (!isset($_POST['newname_meaning'])) $meaning = '';
	else $meaning = strtolower(sanitize($_POST['newname_meaning']));
	
	db_set_active('babynames');
	$q = db_insert('name_meaning');
	db_set_active();
	$q -> fields (array('name' => $name, 'origin' => $origin, 'meaning' => $meaning))
	   -> execute();
}


function babynames_rate_name () {	
	global $user;
	if (!$user->uid) {
		drupal_set_message('Must login.', 'error');
		return;	
	}
	
	if (!isset($_POST['ratename']) || !isset($_POST['ratename_gender'])) return;
	$_POST['ratename'] = trim($_POST['ratename']);
	$name = strtolower(sanitize($_POST['ratename']));
	//$gender = (int)$_POST['ratename_gender'];	
	
	db_set_active('babynames');
	$q = db_select('name_ratings', 'nr');
	db_set_active();
	$q -> fields ('nr', array ('fn_rating', 'mn_rating'))
	//   -> condition ('nr.gender', $gender)
	   -> condition ('nr.name', $name)
	   -> condition ('nr.user', $user->name)
	   -> range (0,1);
	$record = $q -> execute() -> fetchAssoc();
	
	if (!$record) {
		$fnr = 0;
		$mnr = 0;
	} else {
		$fnr = $record['fn_rating'];
		$mnr = $record['mn_rating'];
	}
	
	if (isset($_POST['ratename_fup'])) $fnr++;
	if (isset($_POST['ratename_fdown'])) $fnr--;
	if (isset($_POST['ratename_mup'])) $mnr++;
	if (isset($_POST['ratename_mdown'])) $mnr--;
	
	if (!$record) {
		db_set_active('babynames');
		$q = db_insert('name_ratings');
		db_set_active();
		$q -> fields (array('name' => $name, 'user' => $user->name, 'fn_rating' => $fnr, 'mn_rating' => $mnr))
		   -> execute();
	} else {
		db_set_active('babynames');
		$q = db_update('name_ratings');
		db_set_active();
		$q -> fields (array('fn_rating' => $fnr, 'mn_rating' => $mnr))
		   -> condition ('name', $name)
		   -> condition ('user', $user->name)
		   -> execute();
	}	
}

function sanitize ($var, $allowspecial = '') {  
  $var = trim($var);
  $allow = '-0-9\p{L}_'.$allowspecial;
  $str = preg_replace('/[^'.$allow.']/u', '', $var);
  $str = filter_var($str, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW);
  return $str;
}



