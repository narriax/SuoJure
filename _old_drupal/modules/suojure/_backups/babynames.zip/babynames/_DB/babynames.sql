-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 28, 2016 at 06:11 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `babynames`
--

-- --------------------------------------------------------

--
-- Table structure for table `names`
--

CREATE TABLE IF NOT EXISTS `names` (
  `name` varchar(32) NOT NULL,
  `gender` int(1) NOT NULL,
  `root_variant` varchar(32) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `names`
--

INSERT INTO `names` (`name`, `gender`, `root_variant`) VALUES
('adrian', 0, 'hadrian'),
('aiden', 0, ''),
('alexander', 0, ''),
('amber', 1, ''),
('andrew', 0, ''),
('chris', 0, 'christopher'),
('christian', 0, 'christopher'),
('christina', 1, ''),
('christopher', 0, ''),
('christy', 1, 'christina'),
('erin', 1, ''),
('ethan', 0, ''),
('hadrian', 0, ''),
('jade', 1, ''),
('jane', 1, 'johanna'),
('johanna', 1, ''),
('julia', 1, ''),
('keira', 1, ''),
('michael', 0, ''),
('nathan', 0, 'nathaniel'),
('nathaniel', 0, ''),
('ryan', 0, ''),
('vivian', 1, ''),
('xander', 0, 'alexander'),
('zach', 0, 'zechariah'),
('zander', 0, 'alexander'),
('zaya', 1, 'zoe'),
('zechariah', 0, ''),
('zoe', 1, ''),
('zoelle', 1, 'zoe');

-- --------------------------------------------------------

--
-- Table structure for table `name_meaning`
--

CREATE TABLE IF NOT EXISTS `name_meaning` (
  `name` varchar(32) NOT NULL,
  `origin` varchar(16) NOT NULL,
  `meaning` varchar(128) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `name_meaning`
--

INSERT INTO `name_meaning` (`name`, `origin`, `meaning`) VALUES
('aiden', 'celtic', 'fiery'),
('alexander', 'greek', 'defenderofmen'),
('amber', 'english', 'amber'),
('andrew', 'greek', 'strongmanly'),
('christina', 'greek', 'achristian'),
('christopher', 'roman', 'bearerofchrist'),
('erin', 'irish', 'fromtheislandtothewest'),
('ethan', 'hebrew', 'strong'),
('hadrian', 'roman', 'fromadria'),
('jade', 'spanish', 'stoneoftheside'),
('johanna', 'hebrew', 'godisgracious'),
('julia', 'roman', 'youthful'),
('keira', 'irish', 'littledarkone'),
('michael', 'hebrew', 'likegod'),
('nathaniel', 'hebrew', 'gift of God'),
('ryan', 'irish', 'littleking'),
('vivian', 'roman', 'life'),
('zechariah', 'hebrew', 'the Lord has remembered'),
('zoe', 'greek', 'life');

-- --------------------------------------------------------

--
-- Table structure for table `name_ratings`
--

CREATE TABLE IF NOT EXISTS `name_ratings` (
  `name` varchar(32) NOT NULL,
  `user` varchar(32) NOT NULL,
  `fn_rating` int(3) NOT NULL DEFAULT '0',
  `mn_rating` int(3) NOT NULL DEFAULT '0',
  KEY `name` (`name`),
  KEY `user` (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `name_ratings`
--

INSERT INTO `name_ratings` (`name`, `user`, `fn_rating`, `mn_rating`) VALUES
('aiden', 'narriax', 1, 0),
('michael', 'narriax', 0, 3),
('adrian', 'narriax', 1, 0),
('zac', 'narriax', 1, 0),
('zach', 'narriax', 2, 0),
('ryan', 'narriax', 0, 1),
('ethan', 'narriax', 0, 1),
('christopher', 'narriax', 0, 3),
('zoe', 'narriax', 1, 0),
('zoelle', 'narriax', 2, 0),
('vivian', 'narriax', 0, 1),
('johanna', 'narriax', 0, 1),
('jane', 'narriax', 1, 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
